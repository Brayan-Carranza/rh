

<?php $__env->startSection('contenido'); ?>

  

    <div class="container col-md-6 mt-4">
        <h6 class="display-6 text-center mt-8 mb-3">Registro de equipo</h6>

        <div class="card text-center font-monospace">
            <div class="card-header">
                <title>Equipo</title>
            </div>
            <div class="card-body">
                <form method="post" action="<?php echo e(route('C-e.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <input type="text" class="form-control" placeholder="Proveedor" name="txtProveedor"
                            aria-describedby="basic-addon1">
                    </div>
                    <div>
                        <?php if($errors->all()): ?>
                            <p class="text-danger fst-italic"><?php echo e($errors->first('txtProveedor')); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <input type="text" class="form-control" placeholder="Descripcion" name="txtDescripcion"
                            aria-describedby="basic-addon1">
                    </div>
                    <div>
                        <?php if($errors->all()): ?>
                            <p class="text-danger fst-italic"><?php echo e($errors->first('txtDescripcion')); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <input type="text" class="form-control" placeholder="Precio U" name="txtPrecioU"
                            aria-describedby="basic-addon1">
                    </div>
                    <div>
                        <?php if($errors->all()): ?>
                            <p class="text-danger fst-italic"><?php echo e($errors->first('txtPrecioU')); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <input type="text" class="form-control" placeholder="Factura" name="txtFactura"
                            aria-describedby="basic-addon1">
                    </div>
                    <div>
                        <?php if($errors->all()): ?>
                            <p class="text-danger fst-italic"><?php echo e($errors->first('txtFactura')); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <input type="text" class="form-control" placeholder="Nombre" name="txtNombreE"
                            aria-describedby="basic-addon1">
                    </div>
                    <div>
                        <?php if($errors->all()): ?>
                            <p class="text-danger fst-italic"><?php echo e($errors->first('txtNombreE')); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <input type="text" class="form-control" placeholder="Procesador" name="txtProcesador"
                            aria-describedby="basic-addon1">
                    </div>
                    <div>
                        <?php if($errors->all()): ?>
                            <p class="text-danger fst-italic"><?php echo e($errors->first('txtProcesador')); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <input type="text" class="form-control" placeholder="Nucleos" name="txtNucleos"
                            aria-describedby="basic-addon1">
                    </div>
                    <div>
                        <?php if($errors->all()): ?>
                            <p class="text-danger fst-italic"><?php echo e($errors->first('txtNucleos')); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <input type="text" class="form-control" placeholder="Almacenamiento" name="txtAlmace"
                            aria-describedby="basic-addon1">
                    </div>
                    <div>
                        <?php if($errors->all()): ?>
                            <p class="text-danger fst-italic"><?php echo e($errors->first('txtAlmace')); ?></p>
                        <?php endif; ?>

                    </div>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <input type="text" class="form-control" placeholder="RAM" name="txtRAAM"
                            aria-describedby="basic-addon1">
                    </div>
                    <div>
                        <?php if($errors->all()): ?>
                            <p class="text-danger fst-italic"><?php echo e($errors->first('txtRAAM')); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <input type="text" class="form-control" placeholder="Identidicador de dispositivo"
                            name="txtIdentificador" aria-describedby="basic-addon1">
                    </div>
                    <div>
                        <?php if($errors->all()): ?>
                            <p class="text-danger fst-italic"><?php echo e($errors->first('txtIdentificador')); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <input type="text" class="form-control" placeholder="ID del producto" name="txtIdpro"
                            aria-describedby="basic-addon1">
                    </div>
                    <div>
                        <?php if($errors->all()): ?>
                            <p class="text-danger fst-italic"><?php echo e($errors->first('txtIdpro')); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <label class="input-group-text" for="inputGroupSelect01">Status</label>
                        <select class="form-select" id="inputGroupSelect01" name="txtStatus">
                            <option selected>Seleccionar...</option>
                            <option value="En uso">En uso</option>
                            <option value="Sin Uso">Sin uso</option>
                        </select>
                    </div>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <input type="text" class="form-control" placeholder="Equipo" name="txtEquipo"
                            aria-describedby="basic-addon1">
                    </div>
                    <div>
                        <?php if($errors->all()): ?>
                            <p class="text-danger fst-italic"><?php echo e($errors->first('txtEquipo')); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <input type="text" class="form-control" placeholder="Matricula" name="txtMatricula"
                            aria-describedby="basic-addon1">
                    </div>
                    <?php if($errors->all()): ?>
                        <p class="text-danger fst-italic"><?php echo e($errors->first('txtMatricula')); ?></p>
                    <?php endif; ?>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <input type="text" class="form-control" placeholder="Marca" name="txtMarca"
                            aria-describedby="basic-addon1">
                    </div>
                    <?php if($errors->all()): ?>
                        <p class="text-danger fst-italic"><?php echo e($errors->first('txtMarca')); ?></p>
                    <?php endif; ?>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <input type="text" class="form-control" placeholder="Modelo" name="txtModelo"
                            aria-describedby="basic-addon1">
                    </div>
                    <?php if($errors->all()): ?>
                        <p class="text-danger fst-italic"><?php echo e($errors->first('txtModelo')); ?></p>
                    <?php endif; ?>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <input type="text" class="form-control" placeholder="Color" name="txtColor"
                            aria-describedby="basic-addon1">
                    </div>
                    <?php if($errors->all()): ?>
                        <p class="text-danger fst-italic"><?php echo e($errors->first('txtColor')); ?></p>
                    <?php endif; ?>

                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <span class="input-group-text">Fecha compra</span>
                        <input type="date" class="form-control" aria-label="form-label" name="txtFechaC">
                    </div>
                    <?php if($errors->all()): ?>
                        <p class="text-danger fst-italic"><?php echo e($errors->first('txtFechaC')); ?></p>
                    <?php endif; ?>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <input type="text" class="form-control" placeholder="Estado" name="txtEstadoC"
                            aria-describedby="basic-addon1">
                    </div>
                    <?php if($errors->all()): ?>
                        <p class="text-danger fst-italic"><?php echo e($errors->first('txtEstadoC')); ?></p>
                    <?php endif; ?>


                    <div class="card-footer text-muted">
                        <button hrf="Archivos" type="submit" class="btn btn-danger">Registrar equipo</button>
                    </div>


                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ledsa\resources\views/EqTrabajo.blade.php ENDPATH**/ ?>