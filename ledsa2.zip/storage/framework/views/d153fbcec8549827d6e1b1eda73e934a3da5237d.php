<!-- Modal -->
<?php if(session()->has('Eliminacion')): ?>
    <?php echo "<script> swal('Todo correcto', 'Empleado Eliminado','success')</script>"; ?>

<?php endif; ?>
<div class="modal fade" id="ModalEliminarB-<?php echo e($id); ?>" data-bs-backdrop="static" data-bs-keyboard="false"
    tabindex="-1" aria-labelledby="ModalEliminarB" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Eliminar Empleado.</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <?php $__currentLoopData = $resultBa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consulta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($consulta->idEmpleado == $id): ?>
                    <div class="modal-body">
                        <form method="post" action="<?php echo e(route('ban.update', $consulta->idEmpleado)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <div class="mb-3">
                                <label class="form-label "><?php echo e($consulta->Banco); ?> </label>
                            </div>
                            <div class="mb-3">
                                <label class="form-label "><?php echo e($consulta->Cuenta); ?> </label>
                            </div>
                            <div class="mb-3">
                                <label class="form-label "><?php echo e($consulta->Clabe_interbancaria); ?> </label>
                            </div>

                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="modal-footer">
                <form action="<?php echo e(route('Empleado.destroy', $consulta->idEmpleado)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button type="submit" class="btn btn-success">Si, eliminalo</button>
                </form>
                <a href="<?php echo e(route('ban.index')); ?>" class="btn btn-danger">No, regresame</a>
                </form>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\ledsa2\resources\views/M-EliminarB.blade.php ENDPATH**/ ?>