
<?php $__env->startSection('contenido'); ?>
    <?php if(session()->has('confirmado')): ?>
        <?php echo "<script> swal('Todo correcto', 'Equipo Guardado','success')</script>"; ?>

    <?php endif; ?>

<?php $__env->startSection('css'); ?>
    <?php if(session()->has('Actualizado')): ?>
        <?php echo "<script> swal('Todo correcto', 'Equipo Actualizado','success')</script>"; ?>

    <?php endif; ?>

    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap5.min.css">
<?php $__env->stopSection(); ?>
<title>Consulta equipos.</title>

<div class="container mt-4 table-responsive table-align-middle">
    <table id="C_equipo" class="table table-striped" style="width:100%">
        <thead>

            <tr class="align-bottom">
                <th scope="col">IdEquipo</th>
                <th scope="col">Fecha_C</th>
                <th scope="col">Proveedor</th>
                <th scope="col">Descripcion</th>
                <th scope="col">Precio_U</th>
                <th scope="col">Factura</th>
                <th scope="col">Nombre</th>
                <th scope="col">Procesador</th>
                <th scope="col">Nucleos</th>
                <th scope="col">Almacenamiento</th>
                <th scope="col">RAM</th>
                <th scope="col">Ide_Equipo</th>
                <th scope="col">ProductoID</th>
                <th scope="col">Status </th>
                <th scope="col">Equipo</th>
                <th scope="col">Matricula</th>
                <th scope="col">Marca</th>
                <th scope="col">Modelo</th>
                <th scope="col">Color</th>
                <th scope="col">Estado</th>
                <th scope="col">Actualizar</th>
                <th scope="col">Eliminar</th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $resultEqui; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consulta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($consulta->idEquipo); ?></th>
                    <td><?php echo e($consulta->FechaC); ?></td>
                    <td><?php echo e($consulta->Proveedor); ?></td>
                    <td><?php echo e($consulta->Descripcion); ?></td>
                    <td><?php echo e($consulta->PrecioU); ?></td>
                    <td><?php echo e($consulta->Factura); ?></td>
                    <td><?php echo e($consulta->Nombre); ?></td>
                    <td><?php echo e($consulta->Procesador); ?></td>
                    <td><?php echo e($consulta->Nucleos); ?></td>
                    <td><?php echo e($consulta->Almacenamiento); ?></td>
                    <td><?php echo e($consulta->RAAM); ?></td>
                    <td><?php echo e($consulta->Iden_Equipo); ?></td>
                    <td><?php echo e($consulta->ProductoId); ?></td>
                    <td><?php echo e($consulta->Status); ?></td>
                    <td><?php echo e($consulta->Equipo); ?></td>
                    <td><?php echo e($consulta->Matricula); ?></td>
                    <td><?php echo e($consulta->Marca); ?></td>
                    <td><?php echo e($consulta->Modelo); ?></td>
                    <td><?php echo e($consulta->Color); ?></td>
                    <td><?php echo e($consulta->Estado); ?></td>
                    <td><button type="button" class="btn btn-success btn-sm" data-bs-toggle="modal"
                            data-bs-target="#ModalActualizar-<?php echo e($consulta->idEquipo); ?>">
                            Actualizar <i class="bi bi-pencil-square"></i>
                        </button></td>
                    <td> <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal"
                            data-bs-target="#ModalEliminar-<?php echo e($consulta->idEquipo); ?>">
                            Eliminar <i class="bi bi-trash"></i>
                        </button></td>

                </tr>
                <?php echo $__env->make('M-Actualizar', ['id' => $consulta->idEquipo], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('M-Eliminar', ['id' => $consulta->idEquipo], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
        

    </table>
    <?php $__env->startSection('js'); ?>
        <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
        <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap5.min.js"></script>
        <script>
            $(document).ready(function() {
                $('#C_equipo').DataTable({
                    "lengthMenu": [
                        [5, 10, 50, -1],
                        [5, 10, 50, "ALL"]
                    ]
                });
            });
        </script>

    <?php $__env->stopSection(); ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ledsa2\resources\views/C_equipo.blade.php ENDPATH**/ ?>