<!-- Modal -->
<?php if(session()->has('Eliminacion')): ?>
    <?php echo "<script> swal('Todo correcto', 'Empleado Eliminado','success')</script>"; ?>

<?php endif; ?>
<div class="modal fade" id="ModalEliminarE-<?php echo e($id); ?>" data-bs-backdrop="static" data-bs-keyboard="false"
    tabindex="-1" aria-labelledby="ModalEliminarE" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Eliminar Empleado.</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <?php $__currentLoopData = $resultEm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consulta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($consulta->idEmpleado == $id): ?>
                    <div class="modal-body">
                        <form method="post" action="<?php echo e(route('emple.update', $consulta->idEmpleado)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <div class="mb-3">
                                <label class="form-label "><?php echo e($consulta->Nombre); ?> </label>
                            </div>

                            <div class="mb-3">
                                <label class="form-label"><?php echo e($consulta->ApellidoP); ?></label>
                            </div>
                            <div class="mb-3">
                                <label class="form-label "><?php echo e($consulta->ApellidoM); ?> </label>
                            </div>

                            <div class="mb-3">
                                <label class="form-label"><?php echo e($consulta->Celular); ?></label>
                            </div>
                            <div class="mb-3">
                                <label class="form-label "><?php echo e($consulta->Telefono_fijo); ?> </label>
                            </div>

                            <div class="mb-3">
                                <label class="form-label"><?php echo e($consulta->Correo_Personal); ?></label>
                            </div>
                            <div class="mb-3">
                                <label class="form-label "><?php echo e($consulta->Genero); ?> </label>
                            </div>

                            <div class="mb-3">
                                <label class="form-label"><?php echo e($consulta->Fecha_Nacimiento); ?></label>
                            </div>
                            <div class="mb-3">
                                <label class="form-label "><?php echo e($consulta->Nivel_Estudios); ?> </label>
                            </div>

                            <div class="mb-3">
                                <label class="form-label"><?php echo e($consulta->Estado_Civil); ?></label>
                            </div>
                            <div class="mb-3">
                                <label class="form-label "><?php echo e($consulta->Codigo_Postal); ?> </label>
                            </div>

                            <div class="mb-3">
                                <label class="form-label"><?php echo e($consulta->Estado); ?></label>
                            </div>
                            <div class="mb-3">
                                <label class="form-label "><?php echo e($consulta->Municipio); ?> </label>
                            </div>

                            <div class="mb-3">
                                <label class="form-label"><?php echo e($consulta->Direccion); ?></label>
                            </div>
                            <div class="mb-3">
                                <label class="form-label "><?php echo e($consulta->Nombre_C_Emergencia); ?> </label>
                            </div>

                            <div class="mb-3">
                                <label class="form-label"><?php echo e($consulta->Telefono_C_Emergencia); ?></label>
                            </div>
                            <div class="mb-3">
                                <label class="form-label "><?php echo e($consulta->Parentezco); ?> </label>
                            </div>

                            <div class="mb-3">
                                <label class="form-label"><?php echo e($consulta->Grupo_Sanguineo); ?></label>
                            </div>
                            <div class="mb-3">
                                <label class="form-label "><?php echo e($consulta->Tipo_Licencia); ?> </label>
                            </div>
                            <div class="mb-3">
                                <label class="form-label "><?php echo e($consulta->Banco); ?> </label>
                            </div>
                            <div class="mb-3">
                                <label class="form-label "><?php echo e($consulta->Cuenta); ?> </label>
                            </div>
                            <div class="mb-3">
                                <label class="form-label "><?php echo e($consulta->Clabe_interbancaria); ?> </label>
                            </div>
                            <div class="mb-3">
                                <label class="form-label "><?php echo e($consulta->NSS); ?> </label>

                            </div>
                            <div class="mb-3">
                                <label class="form-label "><?php echo e($consulta->CURP); ?> </label>
                            </div>
                            <div class="mb-3">
                                <label class="form-label "><?php echo e($consulta->RFC); ?> </label>
                            </div>

                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="modal-footer">
                <form action="<?php echo e(route('Empleado.destroy', $consulta->idEmpleado)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button type="submit" class="btn btn-success">Si, eliminalo</button>
                </form>
                <a href="<?php echo e(route('emple.index')); ?>" class="btn btn-danger">No, regresame</a>
                </form>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\ledsa2\resources\views/M-EliminarE.blade.php ENDPATH**/ ?>