
<?php $__env->startSection('contenido'); ?>
    <?php if(session()->has('confirmado')): ?>
        <?php echo "<script> swal('Todo correcto', 'Banco Guardado','success')</script>"; ?>

    <?php endif; ?>

<?php $__env->startSection('css'); ?>
    <?php if(session()->has('Actualizado')): ?>
        <?php echo "<script> swal('Todo correcto', 'Banco Actualizado','success')</script>"; ?>

    <?php endif; ?>

    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap5.min.css">
<?php $__env->stopSection(); ?>
<title>Consulta bancos</title>

<div class="container mt-4 table-responsive table-align-middle">
    <table id="C_banco" class="table table-striped" style="width:100%">
        <thead>

            <tr class="align-bottom">
                <th scope="col">IdEmpleado</th>
                <th scope="col">Nombre</th>
                <th scope="col">Banco</th>
                <th scope="col">Cuenta</th>
                <th scope="col">Clabe interbancaria</th>
                <th scope="col">Actualizar</th>
                <th scope="col">Eliminar</th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $resultBa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consulta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($consulta->idEmpleado); ?></th>
                    <td><?php echo e($consulta->Nombre); ?></td>
                    <td><?php echo e($consulta->Banco); ?></td>
                    <td><?php echo e($consulta->Cuenta); ?></td>
                    <td><?php echo e($consulta->Clabe_interbancaria); ?></td>
                    <td><button type="button" class="btn btn-success btn-sm" data-bs-toggle="modal"
                            data-bs-target="#ModalActualizarB-<?php echo e($consulta->idEmpleado); ?>">
                            Actualizar <i class="bi bi-pencil-square"></i>
                        </button></td>
                    <td> <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal"
                            data-bs-target="#ModalEliminarB-<?php echo e($consulta->idEmpleado); ?>">
                            Eliminar <i class="bi bi-trash"></i>
                        </button></td>

                </tr>
                <?php echo $__env->make('M-ActualizarB', ['id' => $consulta->idEmpleado], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('M-EliminarB', ['id' => $consulta->idEmpleado], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
    <?php $__env->startSection('js'); ?>
        <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
        <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap5.min.js"></script>
        <script>
            $(document).ready(function() {
                $('#C_banco').DataTable({
                    "lengthMenu": [
                        [5, 10, 50, -1],
                        [5, 10, 50, "ALL"]
                    ]
                });
            });
        </script>

    <?php $__env->stopSection(); ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ledsa2\resources\views/C_banco.blade.php ENDPATH**/ ?>