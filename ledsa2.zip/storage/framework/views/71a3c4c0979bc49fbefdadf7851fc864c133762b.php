

<?php $__env->startSection('contenido'); ?>
     <?php if(session()->has('confirmacion')): ?>

        <?php echo "<script> swal('Todo correcto', 'Empleado Guardado','success')</script>"; ?>

    <?php endif; ?> 

    <div class="container col-md-6 mt-4">
        <h6 class="display-6 text-center mt-8 mb-3">Registro de empleados</h6>

        <div class="card text-center font-monospace">
            <div class="card-header">
                <title>Empleados</title>
            </div>
            <div class="card-body">
                <form method="post" action="<?php echo e(route('emple.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <input type="text" class="form-control" placeholder="Nombres" name="txtNombre"
                            aria-describedby="basic-addon1">
                    </div>
                    <?php if($errors->all()): ?>
                        <p class="text-danger fst-italic"><?php echo e($errors->first('txtNombre')); ?></p>
                    <?php endif; ?>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <input type="text" class="form-control" placeholder="Apellido Paterno" name="txtApellidoP"
                            aria-describedby="basic-addon1">
                    </div>
                    <?php if($errors->all()): ?>
                        <p class="text-danger fst-italic"><?php echo e($errors->first('txtApellidoP')); ?></p>
                    <?php endif; ?>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <input type="text" class="form-control" placeholder="Apellido Materno" name="txtApellidoM"
                            aria-describedby="basic-addon1">
                    </div>
                    <?php if($errors->all()): ?>
                        <p class="text-danger fst-italic"><?php echo e($errors->first('txtApellidoM')); ?></p>
                    <?php endif; ?>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <input type="text" class="form-control" placeholder="Celular" name="txtCelular"
                            aria-describedby="basic-addon1">
                    </div>
                    <?php if($errors->all()): ?>
                        <p class="text-danger fst-italic"><?php echo e($errors->first('txtCelular')); ?></p>
                    <?php endif; ?>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <input type="text" class="form-control" placeholder="Telefono personal" name="txtTelefono"
                            aria-describedby="basic-addon1">
                    </div>
                    <?php if($errors->all()): ?>
                        <p class="text-danger fst-italic"><?php echo e($errors->first('txtTelefono')); ?></p>
                    <?php endif; ?>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <input type="text" class="form-control" placeholder="Correo Personal" name="txtCorreo"
                            aria-describedby="basic-addon1">
                    </div>
                    <?php if($errors->all()): ?>
                        <p class="text-danger fst-italic"><?php echo e($errors->first('txtCorreo')); ?></p>
                    <?php endif; ?>
                    <div class="form-floating mb-3 m-lg-2 col-sm-6  ">
                        <select class="form-select" id="floatingSelect" name="txtGenero"
                            aria-label="Floating label select example">
                            <option selected>Seleccionar</option>
                            <option value="Femenino">Femenino</option>
                            <option value="Masculino">Masculino</option>
                        </select>
                        <label for="floatingSelect">Genero</label>
                    </div>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <span class="input-group-text">Fecha de nacimiento</span>
                        <input type="date" class="form-control" aria-label="form-label" name="txtFechaN">
                    </div>
                    <?php if($errors->all()): ?>
                        <p class="text-danger fst-italic"><?php echo e($errors->first('txtFechaN')); ?></p>
                    <?php endif; ?>
                    <div class="form-floating mb-3 m-lg-2 col-sm-6  ">
                        <select class="form-select" id="floatingSelect" name="txtEstudios"
                            aria-label="Floating label select example">
                            <option selected>Seleccionar</option>
                            <option value="Primaria">Primaria</option>
                            <option value="Secundaria">Secundaria</option>
                            <option value="Preparatoria">Preparatoria</option>
                            <option value="Licenciatura">Licenciatura</option>
                            <option value="Superior">Superior</option>
                        </select>
                        <label for="floatingSelect">Nivel de estudios</label>
                    </div>
                    <div class="form-floating mb-3 m-lg-2 col-sm-6  ">
                        <select class="form-select" id="floatingSelect" name="txtEstadoC"
                            aria-label="Floating label select example">
                            <option selected>Seleccionar</option>
                            <option value="Soltero">Soltero</option>
                            <option value="Casado">Casado</option>
                            <option value="Viudo">Viudo</option>
                            <option value="Divorciado">Divorciado</option>
                            <option value="Complicado">Es complicado</option>
                        </select>
                        <label for="floatingSelect">Estado civil</label>
                    </div>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <input type="text" class="form-control" placeholder="Codigo postal" name="txtCodigoP"
                            aria-describedby="basic-addon1">
                    </div>
                    <?php if($errors->all()): ?>
                        <p class="text-danger fst-italic"><?php echo e($errors->first('txtCodigoP')); ?></p>
                    <?php endif; ?>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <input type="text" class="form-control" placeholder="Estado" name="txtEstado"
                            aria-describedby="basic-addon1">
                    </div>
                    <?php if($errors->all()): ?>
                        <p class="text-danger fst-italic"><?php echo e($errors->first('txtEstado')); ?></p>
                    <?php endif; ?>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <input type="text" class="form-control" placeholder="Municipio" name="txtMunicipio"
                            aria-describedby="basic-addon1">
                    </div>
                    <?php if($errors->all()): ?>
                        <p class="text-danger fst-italic"><?php echo e($errors->first('txtMunicipio')); ?></p>
                    <?php endif; ?>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <input type="text" class="form-control" placeholder="Direccion" name="txtDireccion"
                            aria-describedby="basic-addon1">
                    </div>
                    <?php if($errors->all()): ?>
                        <p class="text-danger fst-italic"><?php echo e($errors->first('txtDireccion')); ?></p>
                    <?php endif; ?>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <input type="text" class="form-control" placeholder="Nombre contacto de emergencia"
                            name="txtNombreE" aria-describedby="basic-addon1">
                    </div>
                    <?php if($errors->all()): ?>
                        <p class="text-danger fst-italic"><?php echo e($errors->first('txtNombreE')); ?></p>
                    <?php endif; ?>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <input type="text" class="form-control" placeholder="Telefono contacto de emergencia"
                            name="txtTelefonoE" aria-describedby="basic-addon1">
                    </div>
                    <?php if($errors->all()): ?>
                        <p class="text-danger fst-italic"><?php echo e($errors->first('txtTelefonoE')); ?></p>
                    <?php endif; ?>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <input type="text" class="form-control" placeholder="Parentezco" name="txtParentezco"
                            aria-describedby="basic-addon1">
                    </div>
                    <?php if($errors->all()): ?>
                        <p class="text-danger fst-italic"><?php echo e($errors->first('txtParentezco')); ?></p>
                    <?php endif; ?>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <input type="text" class="form-control" placeholder="Grupo sanguineo" name="txtGrupo"
                            aria-describedby="basic-addon1">
                    </div>
                    <?php if($errors->all()): ?>
                        <p class="text-danger fst-italic"><?php echo e($errors->first('txtGrupo')); ?></p>
                    <?php endif; ?>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <label class="input-group-text" for="inputGroupSelect01">Tipo de licencia</label>
                        <select class="form-select" id="inputGroupSelect01" name="txtLicencia">
                            <option selected>Seleccionar...</option>
                            <option value="Ninguna">Ninguna</option>
                            <option value="BE">Tipo B Estatal</option>
                            <option value="BF">Tipo B federal</option>
                            <option value="B-E">Tipo B,E Federal</option>
                        </select>
                    </div>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                      <label class="input-group-text" for="inputGroupSelect01">Tipo de Banco que maneja</label>
                      <select class="form-select" id="inputGroupSelect01" name="txtBanco">
                          <option selected>Seleccionar...</option>
                          <option value="BBVA">BBVA</option>
                          <option value="Santander">Santander</option>
                      </select>
                  </div>
                  <div class="input-group mb-3 m-lg-2 col-sm-7">
                    <input type="text" class="form-control" placeholder="Numero de cuenta" name="txtCuenta"
                        aria-describedby="basic-addon1">
                </div>
                <?php if($errors->all()): ?>
                    <p class="text-danger fst-italic"><?php echo e($errors->first('txtCuenta')); ?></p>
                <?php endif; ?>
                <div class="input-group mb-3 m-lg-2 col-sm-7">
                  <input type="text" class="form-control" placeholder="Clabe interbancaria" name="txtClabe"
                      aria-describedby="basic-addon1">
              </div>
              <?php if($errors->all()): ?>
                  <p class="text-danger fst-italic"><?php echo e($errors->first('txtClabe')); ?></p>
              <?php endif; ?>
              <div class="input-group mb-3 m-lg-2 col-sm-7">
                <input type="text" class="form-control" placeholder="NSS" name="txtNSS"
                    aria-describedby="basic-addon1">
            </div>
            <?php if($errors->all()): ?>
                <p class="text-danger fst-italic"><?php echo e($errors->first('txtNSS')); ?></p>
            <?php endif; ?>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <input type="text" class="form-control" placeholder="CURP" name="txtCURP"
                            aria-describedby="basic-addon1">
                    </div>
                    <?php if($errors->all()): ?>
                        <p class="text-danger fst-italic"><?php echo e($errors->first('txtCURP')); ?></p>
                    <?php endif; ?>
                    <div class="input-group mb-3 m-lg-2 col-sm-7">
                        <input type="text" class="form-control" placeholder="RFC" name="txtRFC"
                            aria-describedby="basic-addon1">
                    </div>
                    <?php if($errors->all()): ?>
                        <p class="text-danger fst-italic"><?php echo e($errors->first('txtRFC')); ?></p>
                    <?php endif; ?>
                    

                    <div class="card-footer text-muted">
                        <button type="submit" class="btn btn-danger">Registrar empleado</button>
                    </div>


                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ledsa\resources\views/Empleado.blade.php ENDPATH**/ ?>