
<?php $__env->startSection('contenido'); ?>
    <?php if(session()->has('confirmado')): ?>
        <?php echo "<script> swal('Todo correcto', 'Empleado Guardado','success')</script>"; ?>

    <?php endif; ?>

<?php $__env->startSection('css'); ?>
    <?php if(session()->has('Actualizado')): ?>
        <?php echo "<script> swal('Todo correcto', 'Empleado Actualizado','success')</script>"; ?>

    <?php endif; ?>

    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap5.min.css">
<?php $__env->stopSection(); ?>
<title>Consulta empleados</title>

<div class="container mt-4 table-responsive table-align-middle">
    <table id="C_empleado" class="table table-striped" style="width:100%">
        <thead>

            <tr class="align-bottom">
                <th scope="col">IdEmpleado</th>
                <th scope="col">Nombre </th>
                <th scope="col">Apellido_P</th>
                <th scope="col">Apellido_M</th>
                <th scope="col">Celular</th>
                <th scope="col">Telefono_P</th>
                <th scope="col">Correo_P</th>
                <th scope="col">Genero</th>
                <th scope="col">Fecha_N</th>
                <th scope="col">N_Estudios</th>
                <th scope="col">E_Civil</th>
                <th scope="col">CP</th>
                <th scope="col">Estado</th>
                <th scope="col">Municipio</th>
                <th scope="col">Direccion </th>
                <th scope="col">C_Emergencia</th>
                <th scope="col">T_Emergencia</th>
                <th scope="col">Parentezco</th>
                <th scope="col">G_Sanguineo</th>
                <th scope="col">T_Licencia</th>
                <th scope="col">NSS</th>
                <th scope="col">CURP</th>
                <th scope="col">RFC</th>
                <th scope="col">Actualizar</th>
                <th scope="col">Eliminar</th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $resultEm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consulta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($consulta->idEmpleado); ?></th>
                    <td><?php echo e($consulta->Nombre); ?></td>
                    <td><?php echo e($consulta->ApellidoP); ?></td>
                    <td><?php echo e($consulta->ApellidoM); ?></td>
                    <td><?php echo e($consulta->Celular); ?></td>
                    <td><?php echo e($consulta->Telefono_fijo); ?></td>
                    <td><?php echo e($consulta->Correo_Personal); ?></td>
                    <td><?php echo e($consulta->Genero); ?></td>
                    <td><?php echo e($consulta->Fecha_Nacimiento); ?></td>
                    <td><?php echo e($consulta->Nivel_Estudios); ?></td>
                    <td><?php echo e($consulta->Estado_Civil); ?></td>
                    <td><?php echo e($consulta->Codigo_Postal); ?></td>
                    <td><?php echo e($consulta->Estado); ?></td>
                    <td><?php echo e($consulta->Municipio); ?></td>
                    <td><?php echo e($consulta->Direccion); ?></td>
                    <td><?php echo e($consulta->Nombre_C_Emergencia); ?></td>
                    <td><?php echo e($consulta->Telefono_C_Emergencia); ?></td>
                    <td><?php echo e($consulta->Parentezco); ?></td>
                    <td><?php echo e($consulta->Grupo_Sanguineo); ?></td>
                    <td><?php echo e($consulta->Tipo_Licencia); ?></td>
                    <td><?php echo e($consulta->NSS); ?></td>
                    <td><?php echo e($consulta->CURP); ?></td>
                    <td><?php echo e($consulta->RFC); ?></td>
                    <td><button type="button" class="btn btn-success btn-sm" data-bs-toggle="modal"
                            data-bs-target="#ModalActualizarE-<?php echo e($consulta->idEmpleado); ?>">
                            Actualizar <i class="bi bi-pencil-square"></i>
                        </button></td>
                    <td> <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal"
                            data-bs-target="#ModalEliminarE-<?php echo e($consulta->idEmpleado); ?>">
                            Eliminar <i class="bi bi-trash"></i>
                        </button></td>

                </tr>
                <?php echo $__env->make('M-ActualizarE', ['id' => $consulta->idEmpleado], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('M-EliminarE', ['id' => $consulta->idEmpleado], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
    <?php $__env->startSection('js'); ?>
        <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
        <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap5.min.js"></script>
        <script>
            $(document).ready(function() {
                $('#C_empleado').DataTable({
                    "lengthMenu": [
                        [5, 10, 50, -1],
                        [5, 10, 50, "ALL"]
                    ]
                });
            });
        </script>

    <?php $__env->stopSection(); ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ledsa2\resources\views/C_empleado.blade.php ENDPATH**/ ?>