<!-- Modal -->
<?php if(session()->has('Eliminacion')): ?>
    <?php echo "<script> swal('Todo correcto', 'Equipo Eliminado','success')</script>"; ?>

<?php endif; ?>
<div class="modal fade" id="ModalEliminar-<?php echo e($id); ?>" data-bs-backdrop="static" data-bs-keyboard="false"
    tabindex="-1" aria-labelledby="ModalEliminar" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Eliminar Equipo.</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <?php $__currentLoopData = $resultEqui; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consulta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($consulta->idEquipo == $id): ?>
                    <div class="modal-body">
                        <form method="post" action="<?php echo e(route('C-e.update', $consulta->idEquipo)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <div class="mb-3">
                                <label class="form-label "><?php echo e($consulta->Proveedor); ?> </label>
                            </div>

                            <div class="mb-3">
                                <label class="form-label"><?php echo e($consulta->Descripcion); ?></label>
                            </div>
                            <div class="mb-3">
                                <label class="form-label "><?php echo e($consulta->PrecioU); ?> </label>
                            </div>

                            <div class="mb-3">
                                <label class="form-label"><?php echo e($consulta->Factura); ?></label>
                            </div>
                            <div class="mb-3">
                                <label class="form-label "><?php echo e($consulta->Nombre); ?> </label>
                            </div>

                            <div class="mb-3">
                                <label class="form-label"><?php echo e($consulta->Procesador); ?></label>
                            </div>
                            <div class="mb-3">
                                <label class="form-label "><?php echo e($consulta->Nucleos); ?> </label>
                            </div>

                            <div class="mb-3">
                                <label class="form-label"><?php echo e($consulta->Almacenamiento); ?></label>
                            </div>
                            <div class="mb-3">
                                <label class="form-label "><?php echo e($consulta->RAAM); ?> </label>
                            </div>

                            <div class="mb-3">
                                <label class="form-label"><?php echo e($consulta->Iden_Equipo); ?></label>
                            </div>
                            <div class="mb-3">
                                <label class="form-label "><?php echo e($consulta->ProductoId); ?> </label>
                            </div>

                            <div class="mb-3">
                                <label class="form-label"><?php echo e($consulta->Status); ?></label>
                            </div>
                            <div class="mb-3">
                                <label class="form-label "><?php echo e($consulta->Equipo); ?> </label>
                            </div>

                            <div class="mb-3">
                                <label class="form-label"><?php echo e($consulta->Matricula); ?></label>
                            </div>
                            <div class="mb-3">
                                <label class="form-label "><?php echo e($consulta->Marca); ?> </label>
                            </div>

                            <div class="mb-3">
                                <label class="form-label"><?php echo e($consulta->Modelo); ?></label>
                            </div>
                            <div class="mb-3">
                                <label class="form-label "><?php echo e($consulta->Color); ?> </label>
                            </div>

                            <div class="mb-3">
                                <label class="form-label"><?php echo e($consulta->FechaC); ?></label>
                            </div>
                            <div class="mb-3">
                                <label class="form-label "><?php echo e($consulta->Estado); ?> </label>
                            </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="modal-footer">
                <form action="<?php echo e(route('EqTrabajo.destroy', $consulta->idEquipo)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button type="submit" class="btn btn-success">Si, eliminalo</button>
                </form>
                <a href="<?php echo e(route('C-e.index')); ?>" class="btn btn-danger">No, regresame</a>
                </form>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\ledsa\resources\views/M-Eliminar.blade.php ENDPATH**/ ?>