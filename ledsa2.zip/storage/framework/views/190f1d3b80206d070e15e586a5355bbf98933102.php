<!-- Modal -->
<?php if(session()->has('Actualizado')): ?>
    <?php echo "<script> swal('Todo correcto', 'Empleado Actualizado','success')</script>"; ?>

<?php endif; ?>
<div class="modal fade" id="ModalActualizarE-<?php echo e($id); ?>" data-bs-backdrop="static" data-bs-keyboard="false"
    tabindex="-1" aria-labelledby="ModalActualizarE" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post" action="<?php echo e(route('emple.update', $id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel">Actualizar empleado.</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <?php $__currentLoopData = $resultEm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultaId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($consultaId->idEmpleado == $id): ?>
                        <div class="modal-body">

                            <div class="input-group mb-3 m-lg-2 col-sm-7">
                                <input type="text" class="form-control" placeholder="Celular"
                                    value="<?php echo e($consultaId->Celular); ?>" name="txtCelular"
                                    aria-describedby="basic-addon1">
                            </div>
                            <div>
                                <?php if($errors->all()): ?>
                                    <p class="text-danger fst-italic"><?php echo e($errors->first('txtCelular')); ?></p>
                                <?php endif; ?>
                            </div>

                            <div class="input-group mb-3 m-lg-2 col-sm-7">
                                <input type="text" class="form-control" placeholder="Telefono Personal"
                                    value="<?php echo e($consultaId->Telefono_fijo); ?>" name="txtTelefono"
                                    aria-describedby="basic-addon1">
                            </div>
                            <div>
                                <?php if($errors->all()): ?>
                                    <p class="text-danger fst-italic"><?php echo e($errors->first('txtTelefono')); ?></p>
                                <?php endif; ?>
                            </div>

                            <div class="form-floating mb-3 m-lg-2 col-sm-6  ">
                                <select class="form-select" id="floatingSelect" name="txtEstadoC"
                                    value="<?php echo e($consultaId->Estado_Civil); ?>" aria-label="Floating label select example">
                                    <option selected>Seleccionar</option>
                                    <option value="Soltero">Soltero</option>
                                    <option value="Casado">Casado</option>
                                    <option value="Viudo">Viudo</option>
                                    <option value="Divorciado">Divorciado</option>
                                    <option value="Complicado">Es complicado</option>
                                </select>
                                <label for="floatingSelect">Estado civil</label>
                            </div>
                            <div class="input-group mb-3 m-lg-2 col-sm-7">
                                <input type="text" class="form-control" placeholder="Codigo Postal"
                                    value="<?php echo e($consultaId->Codigo_Postal); ?>" name="txtCodigoP"
                                    aria-describedby="basic-addon1">
                            </div>
                            <div>
                                <?php if($errors->all()): ?>
                                    <p class="text-danger fst-italic"><?php echo e($errors->first('txtCodigoP')); ?></p>
                                <?php endif; ?>
                            </div>

                            <div class="input-group mb-3 m-lg-2 col-sm-7">
                                <input type="text" class="form-control" placeholder="Estado"
                                    value="<?php echo e($consultaId->Estado); ?>" name="txtEstado" aria-describedby="basic-addon1">
                            </div>
                            <div>
                                <?php if($errors->all()): ?>
                                    <p class="text-danger fst-italic"><?php echo e($errors->first('txtEstado')); ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="input-group mb-3 m-lg-2 col-sm-7">
                                <input type="text" class="form-control" placeholder="Municipio"
                                    value="<?php echo e($consultaId->Municipio); ?>" name="txtMunicipio"
                                    aria-describedby="basic-addon1">
                            </div>
                            <?php if($errors->all()): ?>
                                <p class="text-danger fst-italic"><?php echo e($errors->first('txtMunicipio')); ?></p>
                            <?php endif; ?>
                            <div class="input-group mb-3 m-lg-2 col-sm-7">
                                <input type="text" class="form-control" placeholder="Direccion"
                                    value="<?php echo e($consultaId->Direccion); ?>" name="txtDireccion"
                                    aria-describedby="basic-addon1">
                            </div>
                            <?php if($errors->all()): ?>
                                <p class="text-danger fst-italic"><?php echo e($errors->first('txtDireccion')); ?></p>
                            <?php endif; ?>
                            <div class="input-group mb-3 m-lg-2 col-sm-7">
                                <input type="text" class="form-control" placeholder="Nombre contacto de emergencia"
                                    value="<?php echo e($consultaId->Nombre_C_Emergencia); ?>" name="txtNombreE"
                                    aria-describedby="basic-addon1">
                            </div>
                            <?php if($errors->all()): ?>
                                <p class="text-danger fst-italic"><?php echo e($errors->first('txtNombreE')); ?></p>
                            <?php endif; ?>

                            <div class="input-group mb-3 m-lg-2 col-sm-7">
                                <input type="text" class="form-control" placeholder="Telefono contacto de emergencia"
                                    value="<?php echo e($consultaId->Telefono_C_Emergencia); ?>" name="txtTelefonoE"
                                    aria-describedby="basic-addon1">
                            </div>
                            <?php if($errors->all()): ?>
                                <p class="text-danger fst-italic"><?php echo e($errors->first('txtTelefonoE')); ?></p>
                            <?php endif; ?>
                            <div class="input-group mb-3 m-lg-2 col-sm-7">
                                <input type="text" class="form-control" placeholder="Parentezco"
                                    value="<?php echo e($consultaId->Parentezco); ?>" name="txtParentezco"
                                    aria-describedby="basic-addon1">
                            </div>
                            <?php if($errors->all()): ?>
                                <p class="text-danger fst-italic"><?php echo e($errors->first('txtParentezco')); ?></p>
                            <?php endif; ?>
                            <div class="input-group mb-3 m-lg-2 col-sm-7">
                                <label class="input-group-text" for="inputGroupSelect01">Tipo de licencia</label>
                                <select class="form-select" id="inputGroupSelect01" name="txtLicencia"
                                    value="<?php echo e($consultaId->Tipo_Licencia); ?>">
                                    <option selected>Seleccionar...</option>
                                    <option value="Ninguna">Ninguna</option>
                                    <option value="BE">Tipo B Estatal</option>
                                    <option value="BF">Tipo B federal</option>
                                    <option value="B-E">Tipo B,E Federal</option>
                                </select>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success btn-sm" data-bs-dismiss="modal">Guardar</button>
                    <a href="<?php echo e(route('emple.index')); ?>" class="btn btn-danger btn-sm">Cancelar</a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\ledsa2\resources\views/M-ActualizarE.blade.php ENDPATH**/ ?>