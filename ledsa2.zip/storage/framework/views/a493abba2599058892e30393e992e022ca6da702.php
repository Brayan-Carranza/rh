<!-- Modal -->
<?php if(session()->has('Actualizado')): ?>
    <?php echo "<script> swal('Todo correcto', 'Equipo Actualizado','success')</script>"; ?>

<?php endif; ?>
<div class="modal fade" id="ModalActualizar-<?php echo e($id); ?>" data-bs-backdrop="static" data-bs-keyboard="false"
    tabindex="-1" aria-labelledby="ModalActualizar" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post" action="<?php echo e(route('C-e.update', $id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel">Actualizar equipo.</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <?php $__currentLoopData = $resultEqui; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultaId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($consultaId->idEquipo == $id): ?>
                        <div class="modal-body">

                            <div class="input-group mb-3 m-lg-2 col-sm-7">
                                <input type="text" class="form-control" placeholder="Descripcion"
                                    value="<?php echo e($consultaId->Descripcion); ?>" name="txtDescripcion"
                                    aria-describedby="basic-addon1">
                            </div>
                            <div>
                                <?php if($errors->all()): ?>
                                    <p class="text-danger fst-italic"><?php echo e($errors->first('txtDescripcion')); ?></p>
                                <?php endif; ?>
                            </div>

                            <div class="input-group mb-3 m-lg-2 col-sm-7">
                                <input type="text" class="form-control" placeholder="Nombre"
                                    value="<?php echo e($consultaId->Nombre); ?>" name="txtNombreE" aria-describedby="basic-addon1">
                            </div>
                            <div>
                                <?php if($errors->all()): ?>
                                    <p class="text-danger fst-italic"><?php echo e($errors->first('txtNombreE')); ?></p>
                                <?php endif; ?>
                            </div>

                            <div class="input-group mb-3 m-lg-2 col-sm-7">
                                <input type="text" class="form-control" placeholder="Almacenamiento"
                                    value="<?php echo e($consultaId->Almacenamiento); ?>" name="txtAlmace"
                                    aria-describedby="basic-addon1">
                            </div>
                            <div>
                                <?php if($errors->all()): ?>
                                    <p class="text-danger fst-italic"><?php echo e($errors->first('txtAlmace')); ?></p>
                                <?php endif; ?>

                            </div>
                            <div class="input-group mb-3 m-lg-2 col-sm-7">
                                <input type="text" class="form-control" placeholder="RAM"
                                    value="<?php echo e($consultaId->RAAM); ?>" name="txtRAAM" aria-describedby="basic-addon1">
                            </div>
                            <div>
                                <?php if($errors->all()): ?>
                                    <p class="text-danger fst-italic"><?php echo e($errors->first('txtRAAM')); ?></p>
                                <?php endif; ?>
                            </div>

                            <div class="input-group mb-3 m-lg-2 col-sm-7">
                                <label class="input-group-text" for="inputGroupSelect01">Status</label>
                                <select class="form-select" id="inputGroupSelect01" value="<?php echo e($consultaId->Status); ?>"
                                    name="txtStatus">
                                    <option selected>Seleccionar...</option>
                                    <option value="En uso">En uso</option>
                                    <option value="Sin Uso">Sin uso</option>
                                </select>
                            </div>

                            <div class="input-group mb-3 m-lg-2 col-sm-7">
                                <input type="text" class="form-control" placeholder="Estado"
                                    value="<?php echo e($consultaId->Estado); ?>" name="txtEstadoC"
                                    aria-describedby="basic-addon1">
                            </div>
                            <?php if($errors->all()): ?>
                                <p class="text-danger fst-italic"><?php echo e($errors->first('txtEstadoC')); ?></p>
                            <?php endif; ?>

                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success btn-sm" data-bs-dismiss="modal">Guardar</button>
                    <a href="<?php echo e(route('C-e.index')); ?>" class="btn btn-danger btn-sm">Cancelar</a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\ledsa\resources\views/M-Actualizar.blade.php ENDPATH**/ ?>