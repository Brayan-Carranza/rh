<!-- Modal -->
<?php if(session()->has('Actualizado')): ?>
    <?php echo "<script> swal('Todo correcto', 'Empleado Actualizado','success')</script>"; ?>

<?php endif; ?>
<div class="modal fade" id="ModalActualizarB-<?php echo e($id); ?>" data-bs-backdrop="static" data-bs-keyboard="false"
    tabindex="-1" aria-labelledby="ModalActualizarB" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post" action="<?php echo e(route('ban.update', $id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel">Actualizar banco de empleado.</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <?php $__currentLoopData = $resultBa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultaId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($consultaId->idEmpleado == $id): ?>
                        <div class="modal-body">
                            <div class="input-group mb-3 m-lg-2 col-sm-7">
                                <label class="input-group-text" for="inputGroupSelect01">Tipo de Banco que maneja</label>
                                <select class="form-select" id="inputGroupSelect01" name="txtBanco">
                                    <option selected>Seleccionar...</option>
                                    <option value="BBVA">BBVA</option>
                                    <option value="Santander">Santander</option>
                                </select>
                            </div>
                            <div class="input-group mb-3 m-lg-2 col-sm-7">
                              <input type="text" class="form-control" placeholder="Numero de cuenta" name="txtCuenta"
                                  aria-describedby="basic-addon1">
                          </div>
                          <?php if($errors->all()): ?>
                              <p class="text-danger fst-italic"><?php echo e($errors->first('txtCuenta')); ?></p>
                          <?php endif; ?>
                          <div class="input-group mb-3 m-lg-2 col-sm-7">
                            <input type="text" class="form-control" placeholder="Clabe interbancaria" name="txtClabe"
                                aria-describedby="basic-addon1">
                        </div>
                        <?php if($errors->all()): ?>
                            <p class="text-danger fst-italic"><?php echo e($errors->first('txtClabe')); ?></p>
                        <?php endif; ?>
                            
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success btn-sm" data-bs-dismiss="modal">Guardar</button>
                    <a href="<?php echo e(route('ban.index')); ?>" class="btn btn-danger btn-sm">Cancelar</a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\ledsa2\resources\views/M-ActualizarB.blade.php ENDPATH**/ ?>